package ClasesPrincipales;
import java.util.*;
public interface Observador 
{ 
void actualiza(); 
}

